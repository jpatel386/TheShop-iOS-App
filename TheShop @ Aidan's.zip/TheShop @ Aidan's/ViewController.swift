
//
//  ViewController.swift
//  TheShop @ Aidan's
//
//  Created by Jaisal Patel on 01/03/2016.
//  Copyright © 2016 Jaisal Patel. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController, WKNavigationDelegate {
    
    var webView: WKWebView!
    
    
    let activity = UIActivityIndicatorView(activityIndicatorStyle: .Gray)
    //var activity: UIActivityIndicatorView!
    
    
    
    
    
    override func loadView() {
        webView = WKWebView()
        webView.navigationDelegate = self
        view = webView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
        let url = NSURL(string: "http://theshopataidans.com")!
        if Reachability.isConnectedToNetwork() == true{
            webView.loadRequest(NSURLRequest(URL: url))
            webView.allowsBackForwardNavigationGestures = true
        }
        webView!.navigationDelegate = self
    }
    
    
    
    
    override func viewDidAppear(animated: Bool) {
        if Reachability.isConnectedToNetwork() == false{
            
            let alertController = UIAlertController(title: "No Internet Connection", message:
                "You are not connected to the internet. Given that you order through the internet, you will need this. Once tapping 'ok' please double tap the home button, and close the app. Once connected to the internet, try again.", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "OK I promise to turn on my internet like a good child.", style: UIAlertActionStyle.Default,handler: nil ))
            self.presentViewController(alertController, animated: true, completion: nil)
        }
        
        
        let alertController = UIAlertController(title: "How To Use", message:
            "To navigate between pages, backwards and forwards, you can swipe from left to right from the edge of the screen. This is useful if you're on the order page and no longer want to order.", preferredStyle: UIAlertControllerStyle.Alert)
        alertController.addAction(UIAlertAction(title: "Don't show me again until I come back", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alertController, animated: true, completion: nil)
        
        
        
    }
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func webView(webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        
        activity.startAnimating()
        //activity.hidesWhenStopped = true
    }
    func webView(webView: WKWebView, didFinishNavigation navigation: WKNavigation!) {
        activity.stopAnimating()
        
        
    }
    
    
    
    
    func webView(webView: WKWebView, decidePolicyForNavigationAction navigationAction: WKNavigationAction, decisionHandler: (WKNavigationActionPolicy) -> Void) {
        
        
        
        if navigationAction.navigationType == .LinkActivated  {
            if let newURL = navigationAction.request.URL,
                let host = newURL.host     where !host.containsString("theshop") &&
                UIApplication.sharedApplication().canOpenURL(newURL) &&
                UIApplication.sharedApplication().openURL(newURL) {
                decisionHandler(.Cancel)
            }
            else {
                decisionHandler(.Allow)
            }
        }
        else {
            decisionHandler(.Allow)
        }
        
        
    }
    
    
}


